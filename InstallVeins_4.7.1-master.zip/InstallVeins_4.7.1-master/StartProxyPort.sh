#!/bin/bash

cd $HOME/src/veins

./sumo-launchd.py -vv -c sumo
